package com.filipense.filipense;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FilipenseApplicationTests {

	@Test
	void contextLoads() {
	}

}
